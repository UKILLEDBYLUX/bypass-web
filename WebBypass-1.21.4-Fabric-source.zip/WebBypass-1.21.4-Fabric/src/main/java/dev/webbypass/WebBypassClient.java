package dev.webbypass;

import net.fabricmc.api.ClientModInitializer;

public final class WebBypassClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        // Behavior is implemented by MinecraftClientMixin.
    }
}
