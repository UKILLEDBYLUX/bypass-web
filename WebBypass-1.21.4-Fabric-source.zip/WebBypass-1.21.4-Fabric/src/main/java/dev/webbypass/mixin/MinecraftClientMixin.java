package dev.webbypass.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MinecraftClient.class)
public abstract class MinecraftClientMixin {
    @Shadow public HitResult crosshairTarget;

    @Unique
    private HitResult webBypass$originalTarget;

    /**
     * Only while using cobwebs, temporarily replace a player entity target with
     * the block raycast result. Minecraft's normal attack path is untouched.
     */
    @Inject(method = "doItemUse", at = @At("HEAD"))
    private void webBypass$beforeItemUse(CallbackInfo ci) {
        MinecraftClient client = (MinecraftClient) (Object) this;
        webBypass$originalTarget = null;

        if (client.player == null || client.world == null || client.interactionManager == null) {
            return;
        }
        if (!client.player.getMainHandStack().isOf(Items.COBWEB)) {
            return;
        }
        if (!(crosshairTarget instanceof EntityHitResult entityHit)
                || !(entityHit.getEntity() instanceof PlayerEntity)) {
            return;
        }

        float tickDelta = 1.0F;
        Vec3d start = client.player.getCameraPosVec(tickDelta);
        Vec3d direction = client.player.getRotationVec(tickDelta);
        double reach = client.player.getBlockInteractionRange();
        Vec3d end = start.add(direction.multiply(reach));

        HitResult blockHit = client.world.raycast(new RaycastContext(
                start,
                end,
                RaycastContext.ShapeType.OUTLINE,
                RaycastContext.FluidHandling.NONE,
                client.player
        ));

        if (blockHit.getType() == HitResult.Type.BLOCK) {
            webBypass$originalTarget = crosshairTarget;
            crosshairTarget = blockHit;
        }
    }

    @Inject(method = "doItemUse", at = @At("RETURN"))
    private void webBypass$afterItemUse(CallbackInfo ci) {
        if (webBypass$originalTarget != null) {
            crosshairTarget = webBypass$originalTarget;
            webBypass$originalTarget = null;
        }
    }
}
